import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-cpp-standards-committee',
  templateUrl: './about-cpp-standards-committee.component.html',
  styleUrls: ['./about-cpp-standards-committee.component.css']
})
export class AboutCppStandardsCommitteeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

