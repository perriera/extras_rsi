import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-cpp-wikipedia',
  templateUrl: './about-cpp-wikipedia.component.html',
  styleUrls: ['./about-cpp-wikipedia.component.css']
})
export class AboutCppWikipediaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

