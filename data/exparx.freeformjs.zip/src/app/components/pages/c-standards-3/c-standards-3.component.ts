import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-standards-3',
  templateUrl: './c-standards-3.component.html',
  styleUrls: ['./c-standards-3.component.css']
})
export class CStandards3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

