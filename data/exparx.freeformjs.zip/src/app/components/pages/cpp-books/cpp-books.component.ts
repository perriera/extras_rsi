import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cpp-books',
  templateUrl: './cpp-books.component.html',
  styleUrls: ['./cpp-books.component.css']
})
export class CppBooksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

