import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books-4',
  templateUrl: './books-4.component.html',
  styleUrls: ['./books-4.component.css']
})
export class Books4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

