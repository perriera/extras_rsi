import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-cpp',
  templateUrl: './about-cpp.component.html',
  styleUrls: ['./about-cpp.component.css']
})
export class AboutCppComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

