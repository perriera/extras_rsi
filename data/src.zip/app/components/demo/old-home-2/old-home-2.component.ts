import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-old-home-2',
  templateUrl: './old-home-2.component.html',
  styleUrls: ['./old-home-2.component.css']
})
export class OldHome2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

