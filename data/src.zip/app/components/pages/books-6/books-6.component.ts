import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books-6',
  templateUrl: './books-6.component.html',
  styleUrls: ['./books-6.component.css']
})
export class Books6Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

