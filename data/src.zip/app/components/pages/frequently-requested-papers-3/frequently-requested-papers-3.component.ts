import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frequently-requested-papers-3',
  templateUrl: './frequently-requested-papers-3.component.html',
  styleUrls: ['./frequently-requested-papers-3.component.css']
})
export class FrequentlyRequestedPapers3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

