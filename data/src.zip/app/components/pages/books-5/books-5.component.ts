import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books-5',
  templateUrl: './books-5.component.html',
  styleUrls: ['./books-5.component.css']
})
export class Books5Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

