import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-etymology',
  templateUrl: './etymology.component.html',
  styleUrls: ['./etymology.component.css']
})
export class EtymologyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

