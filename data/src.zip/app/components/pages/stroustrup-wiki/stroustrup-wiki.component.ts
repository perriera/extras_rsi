import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stroustrup-wiki',
  templateUrl: './stroustrup-wiki.component.html',
  styleUrls: ['./stroustrup-wiki.component.css']
})
export class StroustrupWikiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

