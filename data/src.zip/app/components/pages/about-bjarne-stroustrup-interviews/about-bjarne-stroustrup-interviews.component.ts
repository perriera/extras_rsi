import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-bjarne-stroustrup-interviews',
  templateUrl: './about-bjarne-stroustrup-interviews.component.html',
  styleUrls: ['./about-bjarne-stroustrup-interviews.component.css']
})
export class AboutBjarneStroustrupInterviewsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

